def delta_write_safe_test(sp_df_to_write):
        pass